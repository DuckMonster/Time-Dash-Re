Thanks for downloading PLANETER! 

____CONTROLS____

Keyboard: 
	Walking/flying - Arrow keys
	Jumping - Arrow key Up
	Pick up / throw things - X
	Space bubble - Space
	Pause - Escape
	Reset universe - R

Xbox360 gamepad: 
	Walking/Flying - Left thumbstick
	Jumping - A
	Pick up / throw things - X
	Space bubble - B
	Pause - Start
	Reset universe - BACK

____ABOUT____ 

This game was made in the Global Game Jam 2015 over 48 hours. I would like to think of it as a proof of concept. I will expand on this when I am done with my current project(http://ditto.itch.io/farg).

The music is made by Johann Prell (https://soundcloud.com/johann-prell)

____CONTACT____

If you like this game (or hate it) and want to contact me: 
Twitter: @dittomat
Email: DittoMakesGames@gmail.com

____PS____

I keep notes of things I want add to the game. If you have ideas, please contact me and I'll add it to the list! (If you're idea gets added to the game, I will add you're name to the credits when releasing an update!)